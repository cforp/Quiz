var questionSource = new Array();

            
/********************************************************/
/*          ASSOCIATION IMAGE                           */
/********************************************************/

assImage1 = new Array();
assImage1.formatArray = new Array();
assImage1.interactionArray = new Array();
assImage1.answerArray = new Array();

assImage1.questionType = "assMatch";
assImage1.nbColumn = 1;
assImage1.weight = 1;
assImage1.maxAttempt = 1;
assImage1.questionSlide = true;
/* POUR LE BRANCHING  */
assImage1.branching = false;


assImage1.formatArray[0] = new Array();
assImage1.formatArray[0].type = "banner";
assImage1.formatArray[0].value = "<br />Cliquez sur la bonne image";

assImage1.formatArray[1] = new Array();
assImage1.formatArray[1].type = "interaction";

assImage1.interactionArray.setting = new Array();
assImage1.interactionArray.setting.typeAssociation = "image";

assImage1.interactionArray.element = new Array();
assImage1.interactionArray.element[0] = new Array();

/********************************************************/
/*           Définir la descriptions                   */
/********************************************************/
assImage1.interactionArray.element[0].description = new Array();
assImage1.interactionArray.element[0].description[0] = new Array();
assImage1.interactionArray.element[0].description[0].value = "le lavabo";



/********************************************************/
/*     Définir les médias (images ou vidéo ou son)      */
/********************************************************/

assImage1.interactionArray.element[0].elementMedia = new Array();


assImage1.interactionArray.element[0].elementMedia[0] = new Array();
assImage1.interactionArray.element[0].elementMedia[0].id = 0;
assImage1.interactionArray.element[0].elementMedia[0].mediaArray = new Array();

assImage1.interactionArray.element[0].elementMedia[0].mediaArray[0] = new Array(); 
assImage1.interactionArray.element[0].elementMedia[0].mediaArray[0].type="image";
assImage1.interactionArray.element[0].elementMedia[0].mediaArray[0].value="imageResizer.jpg";
assImage1.interactionArray.element[0].elementMedia[0].mediaArray[0].location = "image";
assImage1.interactionArray.element[0].elementMedia[0].mediaArray[0].mediaSetting = new Array();
assImage1.interactionArray.element[0].elementMedia[0].mediaArray[0].mediaSetting.width = 160;
assImage1.interactionArray.element[0].elementMedia[0].mediaArray[0].mediaSetting.height = 145;
assImage1.interactionArray.element[0].elementMedia[0].mediaArray[0].mediaSetting.fancy = false;


assImage1.interactionArray.element[0].elementMedia[1] = new Array();
assImage1.interactionArray.element[0].elementMedia[1].id = 1;
assImage1.interactionArray.element[0].elementMedia[1].mediaArray = new Array();
assImage1.interactionArray.element[0].elementMedia[1].mediaArray[0] = new Array(); 
assImage1.interactionArray.element[0].elementMedia[1].mediaArray[0].type="image";
assImage1.interactionArray.element[0].elementMedia[1].mediaArray[0].value="imageResizer2.jpg";
assImage1.interactionArray.element[0].elementMedia[1].mediaArray[0].location = "image";
assImage1.interactionArray.element[0].elementMedia[1].mediaArray[0].mediaSetting = new Array();
assImage1.interactionArray.element[0].elementMedia[1].mediaArray[0].mediaSetting.width = 160;
assImage1.interactionArray.element[0].elementMedia[1].mediaArray[0].mediaSetting.height = 145;
assImage1.interactionArray.element[0].elementMedia[1].mediaArray[0].mediaSetting.fancy = false;

assImage1.interactionArray.element[0].elementMedia[2] = new Array();
assImage1.interactionArray.element[0].elementMedia[2].id = 2;
assImage1.interactionArray.element[0].elementMedia[2].mediaArray = new Array();
assImage1.interactionArray.element[0].elementMedia[2].mediaArray[0] = new Array(); 
assImage1.interactionArray.element[0].elementMedia[2].mediaArray[0].type="image";
assImage1.interactionArray.element[0].elementMedia[2].mediaArray[0].value="imageResizer3.jpg";
assImage1.interactionArray.element[0].elementMedia[2].mediaArray[0].location = "image";
assImage1.interactionArray.element[0].elementMedia[2].mediaArray[0].mediaSetting = new Array();
assImage1.interactionArray.element[0].elementMedia[2].mediaArray[0].mediaSetting.width = 160;
assImage1.interactionArray.element[0].elementMedia[2].mediaArray[0].mediaSetting.height = 145;
assImage1.interactionArray.element[0].elementMedia[2].mediaArray[0].mediaSetting.fancy = false;

assImage1.interactionArray.element[0].elementMedia[3] = new Array();
assImage1.interactionArray.element[0].elementMedia[3].id = 3;
assImage1.interactionArray.element[0].elementMedia[3].mediaArray = new Array();
assImage1.interactionArray.element[0].elementMedia[3].mediaArray[0] = new Array();
assImage1.interactionArray.element[0].elementMedia[3].mediaArray[0].type="image";
assImage1.interactionArray.element[0].elementMedia[3].mediaArray[0].value="imageResizer4.jpg";
assImage1.interactionArray.element[0].elementMedia[3].mediaArray[0].location = "image";
assImage1.interactionArray.element[0].elementMedia[3].mediaArray[0].mediaSetting = new Array();
assImage1.interactionArray.element[0].elementMedia[3].mediaArray[0].mediaSetting.width = 160;
assImage1.interactionArray.element[0].elementMedia[3].mediaArray[0].mediaSetting.height = 145;
assImage1.interactionArray.element[0].elementMedia[3].mediaArray[0].mediaSetting.fancy = false;

assImage1.interactionArray.element[0].elementMedia[4] = new Array();
assImage1.interactionArray.element[0].elementMedia[4].id = 4;
assImage1.interactionArray.element[0].elementMedia[4].mediaArray = new Array();
assImage1.interactionArray.element[0].elementMedia[4].mediaArray[0] = new Array(); 
assImage1.interactionArray.element[0].elementMedia[4].mediaArray[0].type="image";
assImage1.interactionArray.element[0].elementMedia[4].mediaArray[0].value="imageResizer5.jpg";
assImage1.interactionArray.element[0].elementMedia[4].mediaArray[0].location = "image";
assImage1.interactionArray.element[0].elementMedia[4].mediaArray[0].mediaSetting = new Array();
assImage1.interactionArray.element[0].elementMedia[4].mediaArray[0].mediaSetting.width = 160;
assImage1.interactionArray.element[0].elementMedia[4].mediaArray[0].mediaSetting.height = 145;
assImage1.interactionArray.element[0].elementMedia[4].mediaArray[0].mediaSetting.fancy = false;

assImage1.interactionArray.element[0].elementMedia[5] = new Array();
assImage1.interactionArray.element[0].elementMedia[5].id = 5;
assImage1.interactionArray.element[0].elementMedia[5].mediaArray = new Array();
assImage1.interactionArray.element[0].elementMedia[5].mediaArray[0] = new Array();
assImage1.interactionArray.element[0].elementMedia[5].mediaArray[0].type="image";
assImage1.interactionArray.element[0].elementMedia[5].mediaArray[0].value="imageResizer6.jpg";
assImage1.interactionArray.element[0].elementMedia[5].mediaArray[0].location = "image";
assImage1.interactionArray.element[0].elementMedia[5].mediaArray[0].mediaSetting = new Array();
assImage1.interactionArray.element[0].elementMedia[5].mediaArray[0].mediaSetting.width = 160;
assImage1.interactionArray.element[0].elementMedia[5].mediaArray[0].mediaSetting.height = 145;
assImage1.interactionArray.element[0].elementMedia[5].mediaArray[0].mediaSetting.fancy = false;

assImage1.interactionArray.element[0].elementMedia[6] = new Array();
assImage1.interactionArray.element[0].elementMedia[6].id = 6;
assImage1.interactionArray.element[0].elementMedia[6].mediaArray = new Array();
assImage1.interactionArray.element[0].elementMedia[6].mediaArray[0] = new Array();
assImage1.interactionArray.element[0].elementMedia[6].mediaArray[0].type="image";
assImage1.interactionArray.element[0].elementMedia[6].mediaArray[0].value="imageResizer7.jpg";
assImage1.interactionArray.element[0].elementMedia[6].mediaArray[0].location = "image";
assImage1.interactionArray.element[0].elementMedia[6].mediaArray[0].mediaSetting = new Array();
assImage1.interactionArray.element[0].elementMedia[6].mediaArray[0].mediaSetting.width = 160;
assImage1.interactionArray.element[0].elementMedia[6].mediaArray[0].mediaSetting.height = 145;
assImage1.interactionArray.element[0].elementMedia[6].mediaArray[0].mediaSetting.fancy = false;

assImage1.interactionArray.element[0].elementMedia[7] = new Array();
assImage1.interactionArray.element[0].elementMedia[7].id = 7;
assImage1.interactionArray.element[0].elementMedia[7].mediaArray = new Array();
assImage1.interactionArray.element[0].elementMedia[7].mediaArray[0] = new Array();
assImage1.interactionArray.element[0].elementMedia[7].mediaArray[0].type="image";
assImage1.interactionArray.element[0].elementMedia[7].mediaArray[0].value="imageResizer8.jpg";
assImage1.interactionArray.element[0].elementMedia[7].mediaArray[0].location = "image";
assImage1.interactionArray.element[0].elementMedia[7].mediaArray[0].mediaSetting = new Array();
assImage1.interactionArray.element[0].elementMedia[7].mediaArray[0].mediaSetting.width = 160;
assImage1.interactionArray.element[0].elementMedia[7].mediaArray[0].mediaSetting.height = 145;
assImage1.interactionArray.element[0].elementMedia[7].mediaArray[0].mediaSetting.fancy = false;


assImage1.answerArray[0] = new Array();
assImage1.answerArray[0].value = 3;
assImage1.answerArray[0].weight = 1;
               
this.questionSource[0] = new Array();
this.questionSource[0] = assImage1;   
            

/********************************************************/
/*          ASSOCIATION DESCRIPTION                     */
/********************************************************/

assDesc1 = new Array();
assDesc1.formatArray = new Array();
assDesc1.interactionArray = new Array();
assDesc1.answerArray = new Array();

assDesc1.questionType = "assMatch";
assDesc1.nbColumn = 1;
assDesc1.weight = 1;
assDesc1.maxAttempt = 1;
assDesc1.questionSlide = true;
assDesc1.branching = false;

assDesc1.formatArray[0] = new Array();
assDesc1.formatArray[0].type = "banner";
assDesc1.formatArray[0].value = "<br />Cliquez sur la bonne description";

assDesc1.formatArray[1] = new Array();
assDesc1.formatArray[1].type = "interaction";

assDesc1.interactionArray.setting = new Array();
assDesc1.interactionArray.setting.typeAssociation = "description";

assDesc1.interactionArray.element = new Array();
assDesc1.interactionArray.element[0] = new Array();

/********************************************************/
/*           Définir les descriptions                   */
/********************************************************/

assDesc1.interactionArray.element[0].description = new Array();

assDesc1.interactionArray.element[0].description[0] = new Array();
assDesc1.interactionArray.element[0].description[0].value = "des pingouins";
assDesc1.interactionArray.element[0].description[0].id = 0;

assDesc1.interactionArray.element[0].description[1] = new Array();
assDesc1.interactionArray.element[0].description[1].value = "la location de vélos";
assDesc1.interactionArray.element[0].description[1].id = 1;

assDesc1.interactionArray.element[0].description[2] = new Array();
assDesc1.interactionArray.element[0].description[2].value = "la plaque de rue";
assDesc1.interactionArray.element[0].description[2].id = 2;

assDesc1.interactionArray.element[0].description[3] = new Array();
assDesc1.interactionArray.element[0].description[3].value = "un trottoir";
assDesc1.interactionArray.element[0].description[3].id = 3;

assDesc1.interactionArray.element[0].description[4] = new Array();
assDesc1.interactionArray.element[0].description[4].value = "un passage pour piétons";
assDesc1.interactionArray.element[0].description[4].id = 4;

assDesc1.interactionArray.element[0].description[5] = new Array();
assDesc1.interactionArray.element[0].description[5].value = "le quai de métro";
assDesc1.interactionArray.element[0].description[5].id = 5;

assDesc1.interactionArray.element[0].description[6] = new Array();
assDesc1.interactionArray.element[0].description[6].value = "le nettoyage";
assDesc1.interactionArray.element[0].description[6].id = 6;

assDesc1.interactionArray.element[0].description[7] = new Array();
assDesc1.interactionArray.element[0].description[7].value = "un panneau de signalisation";
assDesc1.interactionArray.element[0].description[7].id = 7;



/********************************************************/
/*     Définir les médias (images ou vidéo ou son)      */
/********************************************************/

assDesc1.interactionArray.element[0].mediaArray = new Array();
assDesc1.interactionArray.element[0].mediaArray[0] = new Array();
 
assDesc1.interactionArray.element[0].mediaArray[0].type="image";
assDesc1.interactionArray.element[0].mediaArray[0].value="Penguins.jpg";
assDesc1.interactionArray.element[0].mediaArray[0].location = "image";
assDesc1.interactionArray.element[0].mediaArray[0].mediaSetting = new Array();
assDesc1.interactionArray.element[0].mediaArray[0].mediaSetting.width = 160;
assDesc1.interactionArray.element[0].mediaArray[0].mediaSetting.height = 145;
assDesc1.interactionArray.element[0].mediaArray[0].mediaSetting.widthRatio = 1;
assDesc1.interactionArray.element[0].mediaArray[0].mediaSetting.heightRatio = 1;
assDesc1.interactionArray.element[0].mediaArray[0].mediaSetting.fancy = false;


assDesc1.answerArray[0] = new Array();
assDesc1.answerArray[0].value = 0;
assDesc1.answerArray[0].weight = 1;
               
this.questionSource[1] = new Array();
this.questionSource[1] = assDesc1;   
