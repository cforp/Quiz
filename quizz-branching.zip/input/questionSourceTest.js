var questionSource = new Array();

/***********************************************/
/*                 CONTENU                  */
/***********************************************/

content1 = new Array();
               
content1.playerIdArray = new Array();
content1.formatArray = new Array();
content1.interactionArray = new Array();
               
              
content1.questionType = "content";
content1.nbColumn = 1;
content1.questionSlide = false;
content1.branching = false;
               
content1.formatArray[0] = new Array();
content1.formatArray[0].type = "banner";
content1.formatArray[0].value = "<h2>L’histoire de Terry Fox</h2>";
               
content1.formatArray[1] = new Array();
content1.formatArray[1].type = "normal";
content1.formatArray[1].value = "";
               
content1.formatArray[2] = new Array();
content1.formatArray[2].type = "normal";
content1.formatArray[2].value = "<p>Vous allez  maintenant répondre à des questions de compréhension. Utilisez vos notes et  votre dictionnaire pour bien comprendre les questions et les explications.</p><p>Pour chaque  question, vous pouvez écouter de nouveau l'histoire avant de répondre.</p>";
content1.formatArray[2].css = "interactionDiv";

content1.formatArray[3] = new Array();
content1.formatArray[3].type = "normal";
content1.formatArray[3].value="<br /><br />";

this.questionSource[0] = new Array();
this.questionSource[0] = content1; 
            
/**********************************************************/
/*                  VRAI OU FAUX                          */
/**********************************************************/
TF1 = new Array();
TF1.formatArray = new Array();
TF1.interactionArray = new Array();
TF1.answerArray = new Array();

TF1.incorrectAnswerFeedback = "<p>Désolé. Mauvaise  réponse. </p>Terry Fox est originaire de la Colombie-Britannique.  Il a grandi dans cette province canadienne. La Colombie est un pays.";
TF1.correctAnswerFeedback = "<p>Vous avez raison!</p>Terry Fox est originaire de la Colombie-Britannique.  Il a grandi dans cette province canadienne. La Colombie est un pays.";

               
TF1.questionType = "trueFalse";
TF1.nbColumn = 1;
TF1.weight = 1;
TF1.maxAttempt = 1;
TF1.questionSlide = true;
TF1.branching = false;
               
TF1.formatArray[0] = new Array();
TF1.formatArray[0].type = "banner";
TF1.formatArray[0].value = "Dites si l’affirmation est vraie ou fausse. ";


TF1.formatArray[1] = new Array();
TF1.formatArray[1].type = "normal";
TF1.formatArray[1].css = "interactionDiv";
TF1.formatArray[1].value = "Terry Fox est originaire de la Colombie.";

TF1.formatArray[2] = new Array();
TF1.formatArray[2].type = "media";
TF1.formatArray[2].mediaArray = new Array();
TF1.formatArray[2].mediaArray[0] = new Array();
TF1.formatArray[2].mediaArray[0].value = "CLIC5_U10_M1_CO_A1_audio1.mp3";
TF1.formatArray[2].mediaArray[0].type = "audio";
TF1.formatArray[2].mediaArray[0].location = "audio";
TF1.formatArray[2].mediaArray[0].mediaSetting = new Array();
TF1.formatArray[2].mediaArray[0].mediaSetting.width = 100;
TF1.formatArray[2].mediaArray[0].mediaSetting.height = 75;

TF1.formatArray[2].mediaArray[0].mediaSetting.fancy = false;
               
TF1.formatArray[3] = new Array();
TF1.formatArray[3].type = "interaction";

TF1.formatArray[4] = new Array();
TF1.formatArray[4].type = "normal";
TF1.formatArray[4].value="<br /><br />";

TF1.interactionArray.setting = new Array();
               
TF1.interactionArray.element = new Array();
TF1.interactionArray.element[0] = new Array();
TF1.interactionArray.element[0].id = 0;
               
TF1.interactionArray.element[0].value = "Vrai";
               
TF1.interactionArray.element[0].mediaArray = new Array();

TF1.interactionArray.element[1] = new Array();
TF1.interactionArray.element[1].value = "Faux";
TF1.interactionArray.element[1].id = 1;
TF1.interactionArray.element[1].mediaArray = new Array();

TF1.answerArray[0] = new Array();
TF1.answerArray[0].id = 0;
TF1.answerArray[0].value = false;
TF1.answerArray[0].weight = 0;
               
TF1.answerArray[1] = new Array();
TF1.answerArray[1].id = 1;
TF1.answerArray[1].value = true;
TF1.answerArray[1].weight = 1;


this.questionSource[1] = new Array();
this.questionSource[1] = TF1;   

/**********************************************************/
/*                  VRAI OU FAUX                          */
/**********************************************************/
TF2 = new Array();
TF2.formatArray = new Array();
TF2.interactionArray = new Array();
TF2.answerArray = new Array();

TF2.incorrectAnswerFeedback = "<p>Désolé. Mauvaise  réponse. </p>Terry Fox était handicapé. On lui a amputé une jambe à  cause d'un cancer. Il portait une prothèse.";
TF2.correctAnswerFeedback = "<p>Vous avez raison!</p>Terry Fox était handicapé. On lui a amputé une jambe à  cause d'un cancer. Il portait une prothèse.";

               
TF2.questionType = "trueFalse";
TF2.nbColumn = 1;
TF2.weight = 1;
TF2.maxAttempt = 1;
TF2.questionSlide = true;

TF2.branching = false;
               
TF2.formatArray[0] = new Array();
TF2.formatArray[0].type = "banner";
TF2.formatArray[0].value = "Dites si l’affirmation est vraie ou fausse. ";


TF2.formatArray[1] = new Array();
TF2.formatArray[1].type = "normal";
TF2.formatArray[1].css = "interactionDiv";
TF2.formatArray[1].value = "Terry Fox était handicapé.";

TF2.formatArray[2] = new Array();
TF2.formatArray[2].type = "media";
TF2.formatArray[2].mediaArray = new Array();
TF2.formatArray[2].mediaArray[0] = new Array();
TF2.formatArray[2].mediaArray[0].value = "CLIC5_U10_M1_CO_A1_audio1.mp3";
TF2.formatArray[2].mediaArray[0].type = "audio";
TF2.formatArray[2].mediaArray[0].location = "audio";
TF2.formatArray[2].mediaArray[0].mediaSetting = new Array();
TF2.formatArray[2].mediaArray[0].mediaSetting.width = 100;
TF2.formatArray[2].mediaArray[0].mediaSetting.height = 75;

TF2.formatArray[2].mediaArray[0].mediaSetting.fancy = false;
               
TF2.formatArray[3] = new Array();
TF2.formatArray[3].type = "interaction";

TF2.formatArray[4] = new Array();
TF2.formatArray[4].type = "normal";
TF2.formatArray[4].value="<br /><br />";

TF2.interactionArray.setting = new Array();
               
TF2.interactionArray.element = new Array();
TF2.interactionArray.element[0] = new Array();
TF2.interactionArray.element[0].id = 0;
               
TF2.interactionArray.element[0].value = "Vrai";
               
TF2.interactionArray.element[0].mediaArray = new Array();

TF2.interactionArray.element[1] = new Array();
TF2.interactionArray.element[1].value = "Faux";
TF2.interactionArray.element[1].id = 1;
TF2.interactionArray.element[1].mediaArray = new Array();

TF2.answerArray[0] = new Array();
TF2.answerArray[0].id = 0;
TF2.answerArray[0].value = true;
TF2.answerArray[0].weight = 1;
               
TF2.answerArray[1] = new Array();
TF2.answerArray[1].id = 1;
TF2.answerArray[1].value = false;
TF2.answerArray[1].weight = 0;


this.questionSource[2] = new Array();
this.questionSource[2] = TF2;   

/**********************************************************/
/*                  VRAI OU FAUX                          */
/**********************************************************/
TF3 = new Array();
TF3.formatArray = new Array();
TF3.interactionArray = new Array();
TF3.answerArray = new Array();

TF3.incorrectAnswerFeedback = "<p>Vous avez raison!</p><p><strong>&nbsp;</strong></p>Le projet de Terry Fox était de traverser le Canada en  courant.";
TF3.correctAnswerFeedback = "<p>Désolé. Mauvaise  réponse. </p>Le projet de Terry Fox était de traverser le Canada en  courant.";

               
TF3.questionType = "trueFalse";
TF3.nbColumn = 1;
TF3.weight = 1;
TF3.maxAttempt = 1;
TF3.questionSlide = true;

TF3.branching = false;
               
TF3.formatArray[0] = new Array();
TF3.formatArray[0].type = "banner";
TF3.formatArray[0].value = "Dites si l’affirmation est vraie ou fausse. ";


TF3.formatArray[1] = new Array();
TF3.formatArray[1].type = "normal";
TF3.formatArray[1].css = "interactionDiv";
TF3.formatArray[1].value = "Le projet de Terry Fox était de traverser la Colombie-Britannique en courant.";

TF3.formatArray[2] = new Array();
TF3.formatArray[2].type = "media";
TF3.formatArray[2].mediaArray = new Array();
TF3.formatArray[2].mediaArray[0] = new Array();
TF3.formatArray[2].mediaArray[0].value = "CLIC5_U10_M1_CO_A1_audio1.mp3";
TF3.formatArray[2].mediaArray[0].type = "audio";
TF3.formatArray[2].mediaArray[0].location = "audio";
TF3.formatArray[2].mediaArray[0].mediaSetting = new Array();
TF3.formatArray[2].mediaArray[0].mediaSetting.width = 100;
TF3.formatArray[2].mediaArray[0].mediaSetting.height = 75;

TF3.formatArray[2].mediaArray[0].mediaSetting.fancy = false;
               
TF3.formatArray[3] = new Array();
TF3.formatArray[3].type = "interaction";

TF3.formatArray[4] = new Array();
TF3.formatArray[4].type = "normal";
TF3.formatArray[4].value="<br /><br />";

TF3.interactionArray.setting = new Array();
               
TF3.interactionArray.element = new Array();
TF3.interactionArray.element[0] = new Array();
TF3.interactionArray.element[0].id = 0;
               
TF3.interactionArray.element[0].value = "Vrai";
               
TF3.interactionArray.element[0].mediaArray = new Array();

TF3.interactionArray.element[1] = new Array();
TF3.interactionArray.element[1].value = "Faux";
TF3.interactionArray.element[1].id = 1;
TF3.interactionArray.element[1].mediaArray = new Array();

TF3.answerArray[0] = new Array();
TF3.answerArray[0].id = 0;
TF3.answerArray[0].value = false;
TF3.answerArray[0].weight = 0;
               
TF3.answerArray[1] = new Array();
TF3.answerArray[1].id = 1;
TF3.answerArray[1].value = true;
TF3.answerArray[1].weight = 1;


this.questionSource[3] = new Array();
this.questionSource[3] = TF3;   

/********************************************************/
/*          Wordbank              */
/********************************************************/


WB1 = new Array();
WB1.formatArray = new Array();
WB1.interactionArray = new Array();
WB1.answerArray = new Array();

WB1.questionType = "texteTrouDrag";
WB1.nbColumn = 1;
WB1.weight = 1;
WB1.maxAttempt = 2;
WB1.questionSlide = true;
WB1.customFeedback = true;
WB1.branching = false;

WB1.formatArray[0] = new Array();
WB1.formatArray[0].type = "banner";
WB1.formatArray[0].value = "<h2>Terry Fox a commencé sa course au Canada…</h2>";

WB1.formatArray[1] = new Array();
WB1.formatArray[1].type = "media";
WB1.formatArray[1].mediaArray = new Array();
WB1.formatArray[1].mediaArray[0] = new Array();
WB1.formatArray[1].mediaArray[0].value = "CLIC5_U10_M1_CO_A1_audio1.mp3";
WB1.formatArray[1].mediaArray[0].type = "audio";
WB1.formatArray[1].mediaArray[0].location = "audio";
WB1.formatArray[1].mediaArray[0].mediaSetting = new Array();
WB1.formatArray[1].mediaArray[0].mediaSetting.width = 100;
WB1.formatArray[1].mediaArray[0].mediaSetting.height = 75;
WB1.formatArray[1].mediaArray[0].mediaSetting.fancy = false;

WB1.formatArray[2] = new Array();
WB1.formatArray[2].type = "interaction";

WB1.interactionArray.element = new Array();

WB1.interactionArray.element[0] = new Array();
WB1.interactionArray.element[0].type = "trou";
WB1.interactionArray.element[0].value = 1;

WB1.answerArray[0] = new Array();
WB1.answerArray[0].value = "en 1958.";
WB1.answerArray[0].weight = 1;
WB1.answerArray[0].id = 0;
WB1.answerArray[0].customFeedback = "Désolé. Mauvaise réponse.";
               
WB1.answerArray[1] = new Array();
WB1.answerArray[1].value = "en 1980.";
WB1.answerArray[1].weight = 0;
WB1.answerArray[1].id = 1;
WB1.answerArray[1].customFeedback = "Bonne réponse.";

WB1.answerArray[2] = new Array();
WB1.answerArray[2].value = "en 1981.";
WB1.answerArray[2].weight = 0;
WB1.answerArray[2].id = 2;
WB1.answerArray[2].customFeedback = "Désolé. Mauvaise réponse.";

this.questionSource[4] = new Array();
this.questionSource[4] = WB1;

/***********************************************/
/*                 CONTENU                  */
/***********************************************/

content2 = new Array();
               
content2.playerIdArray = new Array();
content2.formatArray = new Array();
content2.interactionArray = new Array();
               
content2.questionType = "content";
content2.nbColumn = 1;
content2.questionSlide = false;
content2.branching = false;
               
content2.formatArray[0] = new Array();
content2.formatArray[0].type = "banner";
content2.formatArray[0].value = "<h2>Trois dates</h2>";
               
content2.formatArray[1] = new Array();
content2.formatArray[1].type = "normal";
content2.formatArray[1].value = "";
               
content2.formatArray[2] = new Array();
content2.formatArray[2].type = "normal";
content2.formatArray[2].value = "Terry Fox est né en 1958 en Colombie-Britannique. Il a commencé sa course en 1980. Il est mort en 1981.";
content2.formatArray[2].css = "interactionDiv";

content2.formatArray[3] = new Array();
content2.formatArray[3].type = "normal";
content2.formatArray[3].value="<br /><br />";

this.questionSource[5] = new Array();
this.questionSource[5] = content2; 

/********************************************************/
/*          Wordbank              */
/********************************************************/


WB2 = new Array();
WB2.formatArray = new Array();
WB2.interactionArray = new Array();
WB2.answerArray = new Array();

WB2.questionType = "texteTrouDrag";
WB2.nbColumn = 1;
WB2.weight = 1;
WB2.maxAttempt = 2;
WB2.questionSlide = true;
WB2.customFeedback = true;
WB2.branching = false;

WB2.formatArray[0] = new Array();
WB2.formatArray[0].type = "banner";
WB2.formatArray[0].value = "<h2>Terry Fox a voulu faire son marathon de l’espoir pour encourager les Canadiens à faire des dons…</h2>";

WB2.formatArray[1] = new Array();
WB2.formatArray[1].type = "media";
WB2.formatArray[1].mediaArray = new Array();
WB2.formatArray[1].mediaArray[0] = new Array();
WB2.formatArray[1].mediaArray[0].value = "CLIC5_U10_M1_CO_A1_audio1.mp3";
WB2.formatArray[1].mediaArray[0].type = "audio";
WB2.formatArray[1].mediaArray[0].location = "audio";
WB2.formatArray[1].mediaArray[0].mediaSetting = new Array();
WB2.formatArray[1].mediaArray[0].mediaSetting.width = 100;
WB2.formatArray[1].mediaArray[0].mediaSetting.height = 75;
WB2.formatArray[1].mediaArray[0].mediaSetting.fancy = false;

WB2.formatArray[2] = new Array();
WB2.formatArray[2].type = "interaction";

WB2.interactionArray.element = new Array();

WB2.interactionArray.element[0] = new Array();
WB2.interactionArray.element[0].type = "trou";
WB2.interactionArray.element[0].value = 1;

WB2.answerArray[0] = new Array();
WB2.answerArray[0].value = "pour les hôpitaux de la Colombie-Britannique.";
WB2.answerArray[0].weight = 1;
WB2.answerArray[0].id = 0;
WB2.answerArray[0].customFeedback = "Désolé. Mauvaise réponse.";
               
WB2.answerArray[1] = new Array();
WB2.answerArray[1].value = "pour la recherche sur le cancer.";
WB2.answerArray[1].weight = 0;
WB2.answerArray[1].id = 1;
WB2.answerArray[1].customFeedback = "Bonne réponse.";

WB2.answerArray[2] = new Array();
WB2.answerArray[2].value = "pour les handicapés.";
WB2.answerArray[2].weight = 0;
WB2.answerArray[2].id = 2;
WB2.answerArray[2].customFeedback = "Désolé. Mauvaise réponse.";

this.questionSource[6] = new Array();
this.questionSource[6] = WB2;

/***********************************************/
/*                 CONTENU                  */
/***********************************************/

content3 = new Array();
               
content3.playerIdArray = new Array();
content3.formatArray = new Array();
content3.interactionArray = new Array();
               
content3.questionType = "content";
content3.nbColumn = 1;
content3.questionSlide = false;
content3.branching = false;
               
content3.formatArray[0] = new Array();
content3.formatArray[0].type = "banner";
content3.formatArray[0].value = "<h2>Des dons pour la recherche</h2>";
               
content3.formatArray[1] = new Array();
content3.formatArray[1].type = "normal";
content3.formatArray[1].value = "";
               
content3.formatArray[2] = new Array();
content3.formatArray[2].type = "normal";
content3.formatArray[2].value = "Terry Fox voulait sensibiliser les Canadiens au cancer. Il voulait également les encourager à faire des dons pour la recherche sur le cancer.";
content3.formatArray[2].css = "interactionDiv";

content3.formatArray[3] = new Array();
content3.formatArray[3].type = "normal";
content3.formatArray[3].value="<br /><br />";

this.questionSource[7] = new Array();
this.questionSource[7] = content3; 

/**********************************************************/
/*                  VRAI OU FAUX                          */
/**********************************************************/
TF4 = new Array();
TF4.formatArray = new Array();
TF4.interactionArray = new Array();
TF4.answerArray = new Array();

TF4.incorrectAnswerFeedback = "<p>Vous avez raison!</p>Terry Fox n'a pas pu terminer son marathon de  l'espoir. Il est mort du cancer en 1981.";
TF4.correctAnswerFeedback = "<p>Désolé. Mauvaise  réponse. </p>Terry Fox n'a pas pu terminer son marathon de  l'espoir. Il est mort du cancer en 1981.";

               
TF4.questionType = "trueFalse";
TF4.nbColumn = 1;
TF4.weight = 1;
TF4.maxAttempt = 1;
TF4.questionSlide = true;

TF4.branching = false;
               
TF4.formatArray[0] = new Array();
TF4.formatArray[0].type = "banner";
TF4.formatArray[0].value = "Dites si l’affirmation est vraie ou fausse. ";


TF4.formatArray[1] = new Array();
TF4.formatArray[1].type = "normal";
TF4.formatArray[1].css = "interactionDiv";
TF4.formatArray[1].value = "Terry Fox <strong>n</strong>'a <strong>pas</strong> pu terminer son marathon de  l'espoir.";

TF4.formatArray[2] = new Array();
TF4.formatArray[2].type = "media";
TF4.formatArray[2].mediaArray = new Array();
TF4.formatArray[2].mediaArray[0] = new Array();
TF4.formatArray[2].mediaArray[0].value = "CLIC5_U10_M1_CO_A1_audio1.mp3";
TF4.formatArray[2].mediaArray[0].type = "audio";
TF4.formatArray[2].mediaArray[0].location = "audio";
TF4.formatArray[2].mediaArray[0].mediaSetting = new Array();
TF4.formatArray[2].mediaArray[0].mediaSetting.width = 100;
TF4.formatArray[2].mediaArray[0].mediaSetting.height = 75;

TF4.formatArray[2].mediaArray[0].mediaSetting.fancy = false;
               
TF4.formatArray[3] = new Array();
TF4.formatArray[3].type = "interaction";

TF4.formatArray[4] = new Array();
TF4.formatArray[4].type = "normal";
TF4.formatArray[4].value="<br /><br />";

TF4.interactionArray.setting = new Array();
               
TF4.interactionArray.element = new Array();
TF4.interactionArray.element[0] = new Array();
TF4.interactionArray.element[0].id = 0;
               
TF4.interactionArray.element[0].value = "Vrai";
               
TF4.interactionArray.element[0].mediaArray = new Array();

TF4.interactionArray.element[1] = new Array();
TF4.interactionArray.element[1].value = "Faux";
TF4.interactionArray.element[1].id = 1;
TF4.interactionArray.element[1].mediaArray = new Array();

TF4.answerArray[0] = new Array();
TF4.answerArray[0].id = 0;
TF4.answerArray[0].value = true;
TF4.answerArray[0].weight = 1;
               
TF4.answerArray[1] = new Array();
TF4.answerArray[1].id = 1;
TF4.answerArray[1].value = false;
TF4.answerArray[1].weight = 0;


this.questionSource[8] = new Array();
this.questionSource[8] = TF4;   

/***********************************************/
/*                 CONTENU                  */
/***********************************************/

content4 = new Array();
               
content4.playerIdArray = new Array();
content4.formatArray = new Array();
content4.interactionArray = new Array();
               
content4.questionType = "content";
content4.nbColumn = 1;
content4.questionSlide = false;
content4.branching = false;
               
content4.formatArray[0] = new Array();
content4.formatArray[0].type = "banner";
content4.formatArray[0].value = "Chaque année, une course est organisée à la mémoire de Terry Fox. Aujourd’hui, il reste un exemple de courage pour tous les Canadiens.";
               
content4.formatArray[1] = new Array();
content4.formatArray[1].type = "normal";
content4.formatArray[1].css = "interactionDiv";
content4.formatArray[1].value = "L’exercice est terminé.";
               
content4.formatArray[2] = new Array();
content4.formatArray[2].type = "normal";
content4.formatArray[2].value="<br /><br />";

this.questionSource[8] = new Array();
this.questionSource[8] = content4; 
