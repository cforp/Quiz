var oygInit = false;   
var oygError = "Failed to load or execute required JavaScript files."; 