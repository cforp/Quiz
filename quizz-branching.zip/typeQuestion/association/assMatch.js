var assMatch = {};

//Paramètres d'affichage
assMatch.enableMultiColumn = false;
assMatch.enableOptionMedia = true;

//Feedback par défaut pour type de question  *optionel*
assMatch.correctAnswerFeedback = "Bravo! C'est la bonne réponse."
assMatch.incorrectAnswerFeeback = "Désolé, ce n'est pas la bonne réponse."
assMatch.notAnsweredFeedback = "Vous n'avez pas répondu à la question.";

assMatch.questionAnswered = false;

//fonction d'initiation pour question *optionel*
assMatch.init = function(){}

//créer tableau délément "div" pour chaque option de la question
assMatch.createInteraction = function(interactionArray, questionId, answerArray){
	
	var interaction = new Array();
	interaction.component = new Array();
	interaction.component[0] = new Array();
	interaction.component[0].componentParam = new Array()
	
	interaction.interactionParam = new Array();
	
	interaction.interactionParam.questionId = questionId;
	interaction.interactionParam.typeAssociation = interactionArray.setting.typeAssociation;	
	
	interaction.component[0].div = document.createElement('div');
	interaction.component[0].div.className = "divAssMatch";	
	
	// si nous avons le type de question où il faut associer une des descriptions à un média
	if(interaction.interactionParam.typeAssociation == "description"){
		
		// Créer les div pour les descriptions				
		for(var i=0;i<interactionArray.element[0].description.length;i++){
			var divDescription = document.createElement('div');			
			divDescription.className = "divDescription";
			
			var par = document.createElement('p');			
			par.innerHTML = interactionArray.element[0].description[i].value;			
			
			divDescription.appendChild(par);			
			
			// ajouter une référence au tableau d'interaction
			interaction.component[0].componentParam[i] = new Array();
			interaction.component[0].componentParam[i].id = interactionArray.element[0].description[i].id;			
			interaction.component[0].componentParam[i].description = divDescription;		
		}
		// Créer le div pour le média
		//media
		var divMediaContainer = document.createElement("div");
		divMediaContainer.className = "assMatchMedia";
		
		if(interactionArray.element[0].mediaArray != undefined && interactionArray.element[0].mediaArray.length >0){
			interaction.component[0].componentMedia = new Array();
			interaction.component[0].componentMedia[0] = new Array();			
			
			var mediaContainer = document.createElement("div");			
			interaction.component[0].componentMedia[0].media = interactionArray.element[0].mediaArray;
			interaction.component[0].componentMedia[0].container = mediaContainer;
			divMediaContainer.appendChild(mediaContainer);			
		}		
		
		// Placer les description et le media au milieu
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[0].description);
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[1].description);
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[2].description);
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[3].description);
		interaction.component[0].div.appendChild(divMediaContainer);
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[4].description);
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[5].description);
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[6].description);
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[7].description);			
		
				
	}else{	
		interaction.component[0].componentMedia = new Array();
		
		//Placer les médias et la description au milieu							
		for(var i=0;i<interactionArray.element[0].elementMedia.length;i++){
			
			// Créer les div pour le média
			//media
			var divMediaContainer = document.createElement("div");
			divMediaContainer.className = "assMatchMedia";			
						
			interaction.component[0].componentMedia[i] = new Array();			
				
			var mediaContainer = document.createElement("div");			
			interaction.component[0].componentMedia[i].media = interactionArray.element[0].elementMedia[i].mediaArray;
			interaction.component[0].componentMedia[i].container = mediaContainer;
			divMediaContainer.appendChild(mediaContainer);						
			
			// ajouter une référence au tableau d'interaction
			interaction.component[0].componentParam[i] = new Array();
			interaction.component[0].componentParam[i].id = interactionArray.element[0].elementMedia[i].id;			
			interaction.component[0].componentParam[i].media = divMediaContainer;
			
		}
		
		
		//créer le div pour la description		
		var divDescription = document.createElement('div');			
		divDescription.className = "divDescription";
		
		var par = document.createElement('p');			
		par.innerHTML = interactionArray.element[0].description[0].value;			
		
		divDescription.appendChild(par);
		
		
		// Placer les description et le media au milieu
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[0].media);
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[1].media);
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[2].media);
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[3].media);
		interaction.component[0].div.appendChild(divDescription);
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[4].media);
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[5].media);
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[6].media);
		interaction.component[0].div.appendChild(interaction.component[0].componentParam[7].media);			
		
					
	}	
	return interaction;
};

//Définir le comportement des options de la question lors de l'interaction avec l'utilisateur
//ex: hover, onclick
assMatch.setInteraction = function(interaction){
	for(var i=0;i<interaction.component[0].componentParam.length;i++){	
		
		if(interaction.interactionParam.typeAssociation =="description"){ 
			
			// il faut faire la gestion des descriptions comme boutons			
			$(interaction.component[0].componentParam[i].description).click(function(){
				playQuizSoundSelect();								
				$(this).removeClass('ui-state-hover').addClass('ui-state-active').siblings().removeClass('ui-state-active');				
			});
			
			// gérer les hover des descriptions
			$(interaction.component[0].componentParam[i].description).hover(function(){
				playQuizSoundHover();
				$(this).addClass("ui-state-hover");
			},function(){
				$(this).removeClass("ui-state-hover");
			});
							
		}else{
			 // il faut mettre les médias comme bouton
			 $(interaction.component[0].componentParam[i].media).click(function(){
				playQuizSoundSelect();								
				$(this).removeClass('ui-state-hover').addClass('ui-state-active').siblings().removeClass('ui-state-active');				
			});
			
			// gérer les hover des descriptions
			$(interaction.component[0].componentParam[i].media).hover(function(){
				playQuizSoundHover();
				$(this).addClass("ui-state-hover");
			},function(){
				$(this).removeClass("ui-state-hover");
			});
		
		}
		
		
	}
};

//remplir un tableau d'interaction avec les options sélectionnées par l'utlisateur
assMatch.fillUserAnswerArray = function(interaction){
	var userAnswerArray = {};
	
	for(var i=0;i<interaction.component[0].componentParam.length;i++){
		userAnswerArray[i] = {};
		// association de type description
		if(interaction.interactionParam.typeAssociation =="description"){			
			if($(interaction.component[0].componentParam[i].description).hasClass('ui-state-active')){
				userAnswerArray[0] = interaction.component[0].componentParam[i].id;				
			}	
		}
		// association de type image
		else{
			if($(interaction.component[0].componentParam[i].media).hasClass('ui-state-active')){
				userAnswerArray[0] = interaction.component[0].componentParam[i].id;				
			}				
		}		
	}
		
	return userAnswerArray;
	
};

//Vérifier si la question a été répondu
assMatch.checkQuestionAnswered = function(interaction, userAnswer){	
	var checkQuestionAnswered = false;
	for(var i=0;i<interaction.component[0].componentParam.length;i++){
		if(interaction.interactionParam.typeAssociation =="description"){			
			if($(interaction.component[0].componentParam[i].description).hasClass('ui-state-active')){
				return true;	
			}
		}else{
			if($(interaction.component[0].componentParam[i].media).hasClass('ui-state-active')){
				return true;	
			}
		}		
	}	
	
	return checkQuestionAnswered;
};

//vérifier si bonne réponse
assMatch.validateAnswer = function(interaction, userAnswer, answerArray){
	var valid = true;
	var slideScore = 0;
	
	if(userAnswer[0] == answerArray[0].value){
	      	slideScore += answerArray[0].weight;			  
	}else{
		valid = false;
		slideScore = 0;	
	}
		
	
	var result = new Array();
	result[0] = valid;
	result[1] = slideScore;
	return result;
	
};

//enleve l'interactivité de la question, les comportement mis dans setComportment
assMatch.disableQuestion = function(interaction){
	for(var i=0;i<interaction.component[0].componentParam.length;i++){
		if(interaction.interactionParam.typeAssociation =="description"){
			$(interaction.component[0].componentParam[i].description).off('click').off('hover');	
		}		
		else{
			$(interaction.component[0].componentParam[i].media).off('click').off('hover');
		}
	}
};

//Afficher la bonne réponse
assMatch.displayAnswer = function(interaction, answerArray){
	// trouver la réponse de l'utilisateur et mettre type erreur par défaut (sera écrasé si bonne réponse)	
	for(var i=0;i<interaction.component[0].componentParam.length;i++){
		if(interaction.interactionParam.typeAssociation =="description"){
			if($(interaction.component[0].componentParam[i].description).hasClass('ui-state-active')){
				$(interaction.component[0].componentParam[i].description).removeClass('ui-state-active').addClass('ui-state-error');
			}
			$(interaction.component[0].componentParam[answerArray[0].value].description).addClass('ui-assMatch').addClass('ui-state-active').removeClass('ui-state-error');
		}else{
			if($(interaction.component[0].componentParam[i].media).hasClass('ui-state-active')){
				$(interaction.component[0].componentParam[i].media).removeClass('ui-state-active').addClass('ui-state-error');
			}
			$(interaction.component[0].componentParam[answerArray[0].value].media).addClass('ui-assMatch').addClass('ui-state-active').removeClass('ui-state-error');			
		}	
		
	}		
	
	
};
// appelé par le scorm lorsqu'on veut revoir un quiz 
assMatch.loadUserAnswer = function(interaction, suspendDataResume){
	console.log("dans loadUserAnswer");	
	for(var i=0;i<interaction.component[0].componentParam.length;i++){
		if(interaction.interactionParam.typeAssociation =="description"){
			// on met la classe d'erreur par défaut elle sera écrasée si l'utilisateur a mit la bonne réponse 			
			$(interaction.component[0].componentParam[suspendDataResume[0]].description).addClass('ui-assMatch').addClass('ui-state-error');		
		}else{
			$(interaction.component[0].componentParam[suspendDataResume[0]].media).addClass('ui-assMatch').addClass('ui-state-error');
		}
	}	
};

assMatch.studentResponseToString = function(userAnswer, element){
	var answerString ="";
	
}

assMatch.responsePatternToString = function(answerArray, element){
	var answerString ="";
	
	return answerString;
}

assMatch.returnType = function(){
	return"fill-in";
}

assMatch.returnRealType = function(){
	return"assMatch";
}